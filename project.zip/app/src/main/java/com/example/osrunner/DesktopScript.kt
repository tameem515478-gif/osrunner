package com.example.osrunner

/** سكربت يشتغل داخل النظام: يثبّت XFCE + VNC + noVNC أول مرة، ثم يشغّلهم. */
object DesktopScript {
    const val PASSWORD = "kali1234"
    const val URL = "http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale&password=" + PASSWORD

    val script = """#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/01-no-sandbox
grep -q localhost /etc/hosts 2>/dev/null || echo "127.0.0.1 localhost" >> /etc/hosts

if ! command -v tigervncserver >/dev/null 2>&1 || ! command -v websockify >/dev/null 2>&1; then
  echo ">> تثبيت سطح المكتب لأول مرة (حمّل كبير، انتظر بصبر)..."
  apt-get update || exit 1
  apt-get install -y --no-install-recommends xfce4 xfce4-terminal dbus-x11 xauth x11-xserver-utils tigervnc-standalone-server novnc websockify fonts-dejavu-core || exit 1
fi

mkdir -p /root/.vnc /root/.config/tigervnc /tmp/.X11-unix
chmod 1777 /tmp/.X11-unix
echo $PASSWORD | vncpasswd -f > /root/.vnc/passwd
cp /root/.vnc/passwd /root/.config/tigervnc/passwd
chmod 600 /root/.vnc/passwd /root/.config/tigervnc/passwd

cat > /root/.vnc/xstartup <<'XEOF'
#!/bin/sh
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
exec dbus-launch --exit-with-session startxfce4
XEOF
chmod +x /root/.vnc/xstartup

tigervncserver -kill :1 >/dev/null 2>&1
rm -f /tmp/.X1-lock /tmp/.X11-unix/X1
tigervncserver :1 -localhost yes -geometry 1280x720 -depth 24 -xstartup /root/.vnc/xstartup
websockify --web=/usr/share/novnc 6080 127.0.0.1:5901 &
sleep 6
echo DESKTOP_READY
wait
"""
}
