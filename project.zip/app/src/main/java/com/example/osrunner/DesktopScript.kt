package com.example.osrunner

/** سكربت يشتغل داخل النظام: يثبّت XFCE + VNC + noVNC أول مرة، ثم يشغّلهم. */
object DesktopScript {
    const val PASSWORD = "kali1234"
    const val URL = "http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale&password=" + PASSWORD

    val script = """#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/01-no-sandbox
grep -q localhost /etc/hosts 2>/dev/null || echo "127.0.0.1 localhost" >> /etc/hosts

if ! command -v Xtigervnc >/dev/null 2>&1 || ! command -v websockify >/dev/null 2>&1 || ! command -v startxfce4 >/dev/null 2>&1; then
  echo ">> تثبيت سطح المكتب لأول مرة (حمّل كبير، انتظر بصبر)..."
  apt-get update || exit 1
  apt-get install -y --no-install-recommends xfce4 xfce4-terminal dbus-x11 xauth x11-xserver-utils tigervnc-standalone-server novnc websockify fonts-dejavu-core || exit 1
fi
if ! dpkg -s xfonts-base >/dev/null 2>&1 || ! dpkg -s x11-xkb-utils >/dev/null 2>&1; then
  echo ">> تثبيت الخطوط وأدوات الكيبورد..."
  apt-get update
  apt-get install -y --no-install-recommends xfonts-base x11-xkb-utils xkb-data
fi

mkdir -p /root/.vnc /tmp/.X11-unix
chmod 1777 /tmp/.X11-unix
echo $PASSWORD | vncpasswd -f > /root/.vnc/passwd
chmod 600 /root/.vnc/passwd

cat > /root/.vnc/xstartup <<'XEOF'
#!/bin/sh
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
exec dbus-launch --exit-with-session startxfce4
XEOF
chmod +x /root/.vnc/xstartup

rm -f /tmp/.X1-lock /tmp/.X11-unix/X1
echo ">> تشغيل خادم العرض..."
Xtigervnc :1 -localhost -rfbport 5901 -rfbauth /root/.vnc/passwd -SecurityTypes VncAuth -geometry 1280x720 -depth 24 > /root/xvnc.log 2>&1 &
for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
  (echo > /dev/tcp/127.0.0.1/5901) 2>/dev/null && break
  sleep 1
done
if ! (echo > /dev/tcp/127.0.0.1/5901) 2>/dev/null; then
  echo "!! خادم العرض ما اشتغل. آخر سطور السجل:"
  tail -n 40 /root/xvnc.log
  exit 1
fi

echo ">> تشغيل سطح المكتب..."
DISPLAY=:1 /root/.vnc/xstartup > /root/xfce.log 2>&1 &
websockify --web=/usr/share/novnc 6080 127.0.0.1:5901 > /root/websockify.log 2>&1 &
sleep 5
echo DESKTOP_READY
wait
"""
}
