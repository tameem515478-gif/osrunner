package com.example.osrunner

data class Distro(
    val id: String,
    val name: String,
    val url: String,
    val note: String,
    val stripPrefix: String? = null,   // مجلد علوي داخل الأرشيف نشيله أثناء الفك
    val desktop: Boolean = false       // هل يدعم سطح مكتب رسومي
)

object Catalog {
    // تأكد من الروابط قبل النشر، لأن الإصدارات تتغير
    val distros = listOf(
        Distro(
            "kali", "Kali Linux (سطح مكتب)",
            "https://kali.download/nethunter-images/current/rootfs/kali-nethunter-rootfs-minimal-arm64.tar.xz",
            "حجم كبير، وسطح المكتب يحتاج مساحة 3GB+",
            stripPrefix = "kali-arm64", desktop = true
        ),
        Distro(
            "alpine", "Alpine Linux",
            "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.3-aarch64.tar.gz",
            "~4 MB"
        ),
        Distro(
            "ubuntu", "Ubuntu 24.04",
            "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.1-base-arm64.tar.gz",
            "~30 MB"
        )
    )
}
