package com.example.osrunner

data class Distro(val id: String, val name: String, val url: String, val sizeMb: Int)

object Catalog {
    // تأكد من الروابط قبل النشر، لأن الإصدارات تتغير
    val distros = listOf(
        Distro(
            "alpine", "Alpine Linux",
            "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.3-aarch64.tar.gz",
            4
        ),
        Distro(
            "ubuntu", "Ubuntu 24.04",
            "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.1-base-arm64.tar.gz",
            30
        )
    )
}
