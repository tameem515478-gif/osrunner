package com.example.osrunner

import android.annotation.SuppressLint
import android.os.Bundle
import android.system.Os
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = SystemManager(this)
        val runner = ProotRunner(this)

        // نسجّل أي انهيار في التطبيق ونعرضه في التشغيل الجاي
        val crashFile = File(filesDir, "crash.txt")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile.writeText(e.stackTraceToString().take(3000)) } catch (_: Exception) {}
            prev?.uncaughtException(t, e)
        }
        val lastCrash = if (crashFile.exists()) crashFile.readText() else null
        crashFile.delete()

        setContent { MaterialTheme { App(mgr, runner, lastCrash) } }
    }
}

@Composable
fun App(mgr: SystemManager, runner: ProotRunner, lastCrash: String? = null) {
    var desktopFor by remember { mutableStateOf<Distro?>(null) }
    val d = desktopFor
    if (d != null) DesktopScreen(mgr, runner, d) { desktopFor = null }
    else SystemsScreen(mgr, runner, lastCrash) { desktopFor = it }
}

@Composable
fun SystemsScreen(mgr: SystemManager, runner: ProotRunner, lastCrash: String?, onDesktop: (Distro) -> Unit) {
    val scope = rememberCoroutineScope()
    var installed by remember { mutableStateOf(Catalog.distros.filter { mgr.isInstalled(it.id) }.map { it.id }.toSet()) }
    var progress by remember { mutableStateOf<Pair<String, Float>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var session by remember { mutableStateOf<Process?>(null) }
    var log by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var crashText by remember { mutableStateOf(lastCrash) }

    fun run(d: Distro) {
        try {
            val p = runner.start(mgr.dir(d.id))
            session = p; log = ""
            scope.launch(Dispatchers.IO) {
                p.inputStream.bufferedReader().forEachLine { log = (log + it + "\n").takeLast(20000) }
                log += "\n[انتهت الجلسة]\n"
            }
        } catch (e: Exception) { error = e.message }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        val s = session
        if (s == null) {
            Text("الأنظمة", style = MaterialTheme.typography.headlineSmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            crashText?.let {
                Text("آخر انهيار في التطبيق:", color = MaterialTheme.colorScheme.error)
                Text(it.take(1200), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { crashText = null }) { Text("إخفاء") }
            }
            LazyColumn {
                items(Catalog.distros) { d ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleMedium)
                        Text(d.note, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (d.id in installed) {
                                if (d.desktop) Button(onClick = { onDesktop(d) }) { Text("سطح المكتب") }
                                Button(onClick = { run(d) }) { Text("طرفية") }
                                TextButton(onClick = { mgr.remove(d.id); installed -= d.id }) { Text("حذف") }
                            } else {
                                Button(enabled = progress == null, onClick = {
                                    error = null
                                    scope.launch {
                                        try {
                                            mgr.install(d) { progress = d.id to it }
                                            installed += d.id
                                        } catch (e: Exception) { error = e.message }
                                        finally { progress = null }
                                    }
                                }) { Text("تثبيت") }
                            }
                        }
                        progress?.takeIf { it.first == d.id }?.let {
                            LinearProgressIndicator(progress = { it.second }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                        }
                    }
                }
            }
        } else {
            Text(log, Modifier.weight(1f).verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), singleLine = true)
                Button(onClick = {
                    try {
                        s.outputStream.apply { write((input + "\n").toByteArray()); flush() }
                    } catch (e: Exception) {
                        log += "\n[الجلسة مقفلة: ${e.message}. اضغط إغلاق وافتح الطرفية من جديد]\n"
                    }
                    input = ""
                }) { Text("إرسال") }
            }
            TextButton(onClick = { s.destroy(); session = null }) { Text("إغلاق") }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun DesktopScreen(mgr: SystemManager, runner: ProotRunner, d: Distro, onClose: () -> Unit) {
    var log by remember { mutableStateOf("جاري التجهيز...\n") }
    var ready by remember { mutableStateOf(false) }
    var proc by remember { mutableStateOf<Process?>(null) }
    var showLog by remember { mutableStateOf(false) }
    var vncUrl by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                val top = mgr.dir(d.id).list()?.sorted()?.take(25)?.joinToString(", ") ?: "-"
                log += "محتوى النظام: " + top + "\n"
                val vncDir = File(mgr.dir(d.id), "root/.vnc").apply { mkdirs() }
                val pass = VncAuth.randomPassword()
                val pf = File(vncDir, "passwd")
                pf.delete()
                pf.writeBytes(VncAuth.passwdFile(pass))
                Os.chmod(pf.path, 0b110_000_000)
                vncUrl = DesktopScript.url(pass)
                val f = File(mgr.dir(d.id), "root/start-desktop.sh")
                f.parentFile?.mkdirs()
                f.writeText(DesktopScript.script)
                Os.chmod(f.path, 0b111_101_101)
                val p = runner.start(mgr.dir(d.id), listOf("/bin/bash", "/root/start-desktop.sh"))
                proc = p
                p.inputStream.bufferedReader().forEachLine { line ->
                    if (line.contains("DESKTOP_READY")) ready = true
                    log = (log + line + "\n").takeLast(15000)
                }
                log += "\n[انتهت العملية]\n"
            } catch (e: Exception) {
                log += "خطأ: ${e.message}\n"
            }
        }
    }
    DisposableEffect(Unit) { onDispose { proc?.destroy() } }
    BackHandler { proc?.destroy(); onClose() }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        if (ready && !showLog) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = WebViewClient()
                        loadUrl(vncUrl)
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        } else {
            Text(
                if (showLog) log.takeLast(3500) else log,
                Modifier.weight(1f).fillMaxWidth().padding(12.dp).verticalScroll(rememberScrollState()),
                fontFamily = FontFamily.Monospace
            )
        }
        Row(Modifier.padding(horizontal = 8.dp)) {
            TextButton(onClick = { proc?.destroy(); onClose() }) { Text("إغلاق سطح المكتب") }
            if (ready) TextButton(onClick = { showLog = !showLog }) { Text(if (showLog) "الشاشة" else "السجل") }
        }
    }
}
