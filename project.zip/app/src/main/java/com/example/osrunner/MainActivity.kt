package com.example.osrunner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = SystemManager(this)
        val runner = ProotRunner(this)
        setContent { MaterialTheme { App(mgr, runner) } }
    }
}

@Composable
fun App(mgr: SystemManager, runner: ProotRunner) {
    val scope = rememberCoroutineScope()
    var installed by remember { mutableStateOf(Catalog.distros.filter { mgr.isInstalled(it.id) }.map { it.id }.toSet()) }
    var progress by remember { mutableStateOf<Pair<String, Float>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var session by remember { mutableStateOf<Process?>(null) }
    var log by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }

    fun run(d: Distro) {
        try {
            val p = runner.start(mgr.dir(d.id))
            session = p; log = ""
            scope.launch(Dispatchers.IO) {
                p.inputStream.bufferedReader().forEachLine { log = (log + it + "\n").takeLast(20000) }
            }
        } catch (e: Exception) { error = e.message }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        val s = session
        if (s == null) {
            Text("الأنظمة", style = MaterialTheme.typography.headlineSmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            LazyColumn {
                items(Catalog.distros) { d ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name)
                            Text("~${d.sizeMb} MB", style = MaterialTheme.typography.bodySmall)
                        }
                        if (d.id in installed) {
                            Button(onClick = { run(d) }) { Text("تشغيل") }
                            TextButton(onClick = { mgr.remove(d.id); installed -= d.id }) { Text("حذف") }
                        } else {
                            Button(enabled = progress == null, onClick = {
                                error = null
                                scope.launch {
                                    try {
                                        mgr.install(d) { progress = d.id to it }
                                        installed += d.id
                                    } catch (e: Exception) { error = e.message }
                                    finally { progress = null }
                                }
                            }) { Text("تثبيت") }
                        }
                    }
                    progress?.takeIf { it.first == d.id }?.let { LinearProgressIndicator(progress = { it.second }, modifier = Modifier.fillMaxWidth()) }
                }
            }
        } else {
            Text(log, Modifier.weight(1f).verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), singleLine = true)
                Button(onClick = {
                    s.outputStream.apply { write((input + "\n").toByteArray()); flush() }
                    input = ""
                }) { Text("إرسال") }
            }
            TextButton(onClick = { s.destroy(); session = null }) { Text("إغلاق") }
        }
    }
}
