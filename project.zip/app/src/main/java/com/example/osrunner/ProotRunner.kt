package com.example.osrunner

import android.content.Context
import java.io.File

/**
 * يشغّل النظام عبر proot.
 * مهم: أندرويد 10+ يمنع تنفيذ ملفات من مجلد البيانات، فنشحن proot كمكتبة
 * (libproot.so و libproot-loader.so) داخل jniLibs وننفذها من nativeLibraryDir.
 */
class ProotRunner(private val context: Context) {
    private val libDir get() = File(context.applicationInfo.nativeLibraryDir)

    fun start(rootfs: File): Process {
        val tmp = File(context.cacheDir, "proot-tmp").apply { mkdirs() }
        val cmd = listOf(
            File(libDir, "libproot.so").path,
            "--rootfs=${rootfs.path}",
            "-0",                 // مستخدم root وهمي
            "--link2symlink",
            "--kill-on-exit",
            "-b", "/dev",
            "-b", "/proc",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "TERM=xterm-256color",
            "/bin/sh", "-l"
        )
        val pb = ProcessBuilder(cmd).redirectErrorStream(true)
        pb.environment()["PROOT_TMP_DIR"] = tmp.path
        pb.environment()["PROOT_LOADER"] = File(libDir, "libproot-loader.so").path
        return pb.start()
    }
}
