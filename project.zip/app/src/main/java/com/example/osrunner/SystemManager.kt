package com.example.osrunner

import android.content.Context
import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** يحمّل أنظمة لينكس (rootfs) ويفكّها داخل مساحة التطبيق. */
class SystemManager(context: Context) {
    private val root = File(context.filesDir, "systems").apply { mkdirs() }

    fun dir(id: String) = File(root, id)
    fun isInstalled(id: String) = File(dir(id), ".installed").exists()
    fun remove(id: String) { dir(id).deleteRecursively() }

    suspend fun install(d: Distro, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val target = dir(d.id)
        target.deleteRecursively()
        target.mkdirs()

        val conn = URL(d.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        val total = conn.contentLengthLong.coerceAtLeast(1)
        var read = 0L
        val counting = object : FilterInputStream(conn.inputStream) {
            override fun read(): Int = super.read().also { if (it >= 0) read++ }
            override fun read(b: ByteArray, off: Int, len: Int): Int =
                super.read(b, off, len).also { if (it > 0) { read += it; onProgress((read.toFloat() / total).coerceAtMost(1f)) } }
        }

        extract(counting, target)

        // إنترنت داخل النظام
        File(target, "etc").mkdirs()
        File(target, "etc/resolv.conf").writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        File(target, ".installed").writeText("ok")
    }

    private fun extract(input: InputStream, target: File) {
        val base = target.toPath().toAbsolutePath().normalize()
        TarArchiveInputStream(GzipCompressorInputStream(BufferedInputStream(input))).use { tar ->
            var e = tar.nextTarEntry
            while (e != null) {
                val outPath = base.resolve(e.name).normalize()
                if (!outPath.startsWith(base)) throw SecurityException("مسار غير آمن: ${e.name}")
                val out = outPath.toFile()
                when {
                    e.isDirectory -> { out.mkdirs(); Os.chmod(out.path, 0b111_101_101) } // 755
                    e.isSymbolicLink -> {
                        out.parentFile?.mkdirs(); out.delete()
                        Os.symlink(e.linkName, out.path)
                    }
                    e.isLink -> {
                        out.parentFile?.mkdirs(); out.delete()
                        Os.link(base.resolve(e.linkName).normalize().toString(), out.path)
                    }
                    else -> {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { tar.copyTo(it) }
                        Os.chmod(out.path, e.mode and 0b111_111_111_111)
                    }
                }
                e = tar.nextTarEntry
            }
        }
    }
}
