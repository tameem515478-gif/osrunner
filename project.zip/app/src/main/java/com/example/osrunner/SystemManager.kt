package com.example.osrunner

import android.content.Context
import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** يحمّل أنظمة لينكس (rootfs) ويفكّها داخل مساحة التطبيق. */
class SystemManager(context: Context) {
    private val root = File(context.filesDir, "systems").apply { mkdirs() }

    fun dir(id: String) = File(root, id)
    fun isInstalled(id: String) = File(dir(id), ".installed").exists()
    fun remove(id: String) { dir(id).deleteRecursively() }

    suspend fun install(d: Distro, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val target = dir(d.id)
        target.deleteRecursively()
        target.mkdirs()

        val conn = URL(d.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        val total = conn.contentLengthLong.coerceAtLeast(1)
        var read = 0L
        val counting = object : FilterInputStream(conn.inputStream) {
            override fun read(): Int = super.read().also { if (it >= 0) read++ }
            override fun read(b: ByteArray, off: Int, len: Int): Int =
                super.read(b, off, len).also {
                    if (it > 0) { read += it; onProgress((read.toFloat() / total).coerceAtMost(1f)) }
                }
        }

        extract(counting, target, d)

        File(target, "etc").mkdirs()
        File(target, "etc/resolv.conf").writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        File(target, "root").mkdirs()
        File(target, ".installed").writeText("ok")
    }

    private val standardRoot = setOf(
        "bin", "boot", "dev", "etc", "home", "lib", "lib32", "lib64", "libx32", "media",
        "mnt", "opt", "proc", "root", "run", "sbin", "srv", "sys", "tmp", "usr", "var"
    )

    /** يشيل "./" ويشيل المجلد العلوي (إن وُجد) من اسم المدخل. */
    private fun strip(name: String, prefix: String?): String? {
        val n = name.removePrefix("./").trimStart('/')
        if (prefix == null) return n.ifEmpty { null }
        return when {
            n == prefix || n == "$prefix/" -> null
            n.startsWith("$prefix/") -> n.removePrefix("$prefix/").ifEmpty { null }
            else -> n.ifEmpty { null }
        }
    }

    private fun extract(input: InputStream, target: File, d: Distro) {
        val base = target.toPath().toAbsolutePath().normalize()
        val baseCanon = target.canonicalPath   // المسار الحقيقي (على أندرويد /data/data رابط رمزي)
        val buffered = BufferedInputStream(input)
        val decompressed: InputStream =
            if (d.url.endsWith(".xz")) XZCompressorInputStream(buffered) else GzipCompressorInputStream(buffered)

        var prefix: String? = null      // نكتشفه من أول مدخل
        var detected = false
        TarArchiveInputStream(decompressed).use { tar ->
            var e = tar.nextTarEntry
            while (e != null) {
                if (!detected) {
                    val first = e.name.removePrefix("./").trimStart('/').substringBefore('/')
                    if (first.isNotEmpty()) {
                        detected = true
                        if (first !in standardRoot && first != ".") prefix = first
                    }
                }
                val rel = strip(e.name, prefix)
                if (rel != null) {
                    val outPath = base.resolve(rel).normalize()
                    if (!outPath.startsWith(base)) throw SecurityException("مسار غير آمن: ${e.name}")
                    val out = outPath.toFile()
                    out.parentFile?.mkdirs()
                    // تجاهل أي مدخل يمر عبر رابط رمزي مطلق يخرج من النظام
                    val safeParent = out.parentFile?.canonicalPath?.startsWith(baseCanon) ?: true
                    if (safeParent) {
                        when {
                            e.isDirectory -> { out.mkdirs(); Os.chmod(out.path, 0b111_101_101) }
                            e.isSymbolicLink -> { out.delete(); Os.symlink(e.linkName, out.path) }
                            e.isLink -> {
                                val linkRel = strip(e.linkName, prefix)
                                if (linkRel != null) {
                                    out.delete()
                                    Os.link(base.resolve(linkRel).normalize().toString(), out.path)
                                }
                            }
                            e.isCharacterDevice || e.isBlockDevice || e.isFIFO -> { /* نتجاهلها */ }
                            else -> {
                                out.delete()
                                out.outputStream().use { tar.copyTo(it) }
                                Os.chmod(out.path, (e.mode or 0b110_000_000) and 0b111_111_111_111)
                            }
                        }
                    }
                }
                e = tar.nextTarEntry
            }
        }
    }
}
