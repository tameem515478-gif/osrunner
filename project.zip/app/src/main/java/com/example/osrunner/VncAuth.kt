package com.example.osrunner

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/** يولّد ملف كلمة سر بصيغة VNC بدون الحاجة لأداة vncpasswd. */
object VncAuth {
    private val FIXED_KEY = intArrayOf(23, 82, 107, 6, 35, 78, 88, 7)

    fun randomPassword(len: Int = 8): String {
        val chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        return (1..len).map { chars[r.nextInt(chars.length)] }.joinToString("")
    }

    /** محتوى ملف passwd (8 بايت): DES-ECB للكلمة مع المفتاح الثابت (كل بايت معكوس البتات). */
    fun passwdFile(password: String): ByteArray {
        val key = ByteArray(8) { i -> (Integer.reverse(FIXED_KEY[i]) ushr 24).toByte() }
        val plain = ByteArray(8)
        password.toByteArray(Charsets.ISO_8859_1).copyInto(plain, 0, 0, minOf(8, password.length))
        val c = Cipher.getInstance("DES/ECB/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "DES"))
        return c.doFinal(plain)
    }
}
